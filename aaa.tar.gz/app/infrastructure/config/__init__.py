from .base import BaseConfig

__all__ = ("BaseConfig",)
